 <script setup>
  import countries from './components/countries.vue';
</script>

<template>
  <countries></countries>
</template>