import './assets/main.css'

import { createApp } from 'vue'
import App from './App.vue'

createApp(App).mount('#app')





// import { createApp } from "vue";
// import App from "./App.vue";

// // import the package
// import VueAwesomePaginate from "vue-awesome-paginate";

// // import the necessary css file
// import "vue-awesome-paginate/dist/style.css";

// // Register the package
// createApp(App).use(VueAwesomePaginate).mount("#app");